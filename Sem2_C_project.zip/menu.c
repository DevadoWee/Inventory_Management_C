#include "main.h"

char menu()
{
  char command;
  printf("\nWhat do you wish to do?\n");
  printf("Type 1 to display current vaccine quantity.\n");
  printf("Type 2 to update vaccine quantity.\n");
  printf("Type 3 to search vaccine by code.\n");
  printf("Type 4 to display distributed vaccine.\n");
  printf("Type x to exit.\n");
  printf("\nCommand: ");
  command = getchar();
  //get rid of the enter value
  while (getchar() != 10)
    {
    }
  printf("\n");
  return command;
}