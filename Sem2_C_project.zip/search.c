#include "main.h"

void search()
{
  int c;
  char *token;
  int line_count = 0;
  int token_index = 0;
  char *vaccine_content[10];
  char line[80];
  int index = 0;
  int t;
  char code[3];
  int match = 0;

  printf("Please write down the vaccine code: ");
  scanf("%s",code);
  while (getchar() != 10)
    {
    }

  FILE *fvaccine;
  fvaccine = fopen("vaccine.txt","r");
  while (( c = getc(fvaccine)) != EOF)
  {
    if ( c == 10)
    {
      //token = subject but splitted by ,
      token = strtok(line,",");
      //reset index
      token_index = 0;

      while (token != NULL)
      {
        //change token to array
        vaccine_content[token_index++] = token;
        //when element = NUll, exit.
        token = strtok (NULL, ",");
      }
      
      //set each content to structure.
      if (strcmp(vaccine_content[1],code) == 0 || line_count == 0)
      {
        for (t = 0; t < 6; t++)
        {
          switch (t)
          {
            case 0:
            printf("%-14s",vaccine_content[t]);
            break;

            case 1:
            printf("%-8s",vaccine_content[t]);
            break;
            
            case 4:
            printf("%-17s",vaccine_content[t]);
            break;

            default:
            printf("%-10s",vaccine_content[t]);
          }
        }
        printf("\n");
        match++;
        if (match == 2)
        {
          break;
        }
      } 
      
      line_count += 1;
      //reset line
      memset(line,0,79);
      //reset index for line
      index = 0;

    }else
    {
      line[index] = c;
      index++;
    }
  }
  printf("\n");
  fclose(fvaccine);
  if (match == 1)
  {
    printf("\nWrong code, please try again...\n");
    search();
  }
}