#include "main.h"

void display_vaccine()
{
  char *token;//file-subject
  int index = 0;
  int c;
  char line[80];
  int token_index = 0;
  char *vaccine_content[10];
  int t;

  FILE* fvaccine;
  fvaccine = fopen("vaccine.txt","r");
  while (( c = getc(fvaccine)) != EOF)
  {
    if ( c == 10)
    {
      //token = subject but splitted by ,
      token = strtok(line,",");
      //reset index
      token_index = 0;

      while (token != NULL)
      {
        //change token to array
        vaccine_content[token_index++] = token;
        //when element = NUll, exit.
        token = strtok (NULL, ",");
      }
      
      //set each content to structure.
      for (t = 0; t < 6; t++)
      {
        switch (t)
        {
          case 0:
          printf("%-14s",vaccine_content[t]);
          break;

          case 1:
          printf("%-8s",vaccine_content[t]);
          break;
          
          case 4:
          printf("%-17s",vaccine_content[t]);
          break;

          default:
          printf("%-10s",vaccine_content[t]);
        }
      }
      printf("\n");
    
      //reset line
      memset(line,0,79);
      //reset index for line
      index = 0;

    }else
    {
      line[index] = c;
      index++;
    }
  }
  fclose(fvaccine);
}