#include "main.h"
#define SIZE 10
//vaccine size is 5, 10 for reassurance.

struct vaccine
{
  char name[15];
  char code[3];
  char country[15];
  int dosage;
  float pop_covered;
  int quantity;
}VAC[SIZE];

int receive(char*code, int rec_amount)
{
  char *vaccine_subject[10];//file-subject dimension = 80
  char *token;//file-subject
  char string_subject[80];//file-subject
  int struc_count = 0;
  int index = 0;
  int c;
  char line[80];
  int line_count = 0;
  int token_index = 0;
  char *vaccine_content[10];
  int i;
  int find_count = 0;
  int match = 0;
  int t;
  int chosen_line;
  char confirmation;
  int j;
  int highest = 0;
  int num = 0;
  int k;
  

  FILE* fvaccine;
  fvaccine = fopen("vaccine.txt","r");
  printf("\n");

  /*#############take out vaccine subject first*/
  while (!feof(fvaccine))
    {
      fscanf(fvaccine,"%s",string_subject);
      //token = subject but splitted by ,
      token = strtok(string_subject,",");

      while (token != NULL)
      {
        //change token to array
        vaccine_subject[token_index++] = token;
        //when element = NUll, exit.
        token = strtok (NULL, ",");
      }
      break;
    }
  fclose(fvaccine);

  fvaccine = fopen("vaccine.txt","r");
  while (( c = getc(fvaccine)) != EOF)
  {
    if ( c == 10)
    {
      if (line_count >= 1)
      {
        //token = subject but splitted by ,
        token = strtok(line,",");
        //reset index
        token_index = 0;

        while (token != NULL)
        {
          //change token to array
          vaccine_content[token_index++] = token;
          //when element = NUll, exit.
          token = strtok (NULL, ",");
        }
        
        //set each content to structure.
        strcpy(VAC[struc_count].name,vaccine_content[0]);
        strcpy(VAC[struc_count].code,vaccine_content[1]);
        strcpy(VAC[struc_count].country,vaccine_content[2]);
        VAC[struc_count].dosage = atoi(vaccine_content[3]);
        VAC[struc_count].pop_covered = atof(vaccine_content[4]);
        VAC[struc_count].quantity = atoi(vaccine_content[5]);
        struc_count++;
      }
      line_count += 1;
      //reset line
      memset(line,0,79);
      //reset index for line
      index = 0;

    }else
    {
      line[index] = c;
      index++;
    }
  }
  fclose(fvaccine);


  //since struc_count represents the length of structure.
  //Find if it code matches.
  for (i = 0; i < struc_count; i++)
  {
    //compare strings
    if (strcmp(VAC[i].code,code) == 0)
    {
      match = 1;
      break;
    }
  }
  
  
  if (match == 0)
  {
    //returns failure and repeat.
    printf("\nWrong code, please try again.\n");
    return 0;
  } else {
    printf("\nOuh found it...\n\n");
    //display vaccine subject
    for (t = 0; t < 6; t++)
    {
      switch (t)
      {
        case 0:
        printf("%-14s",vaccine_subject[t]);
        break;

        case 1:
        printf("%-8s",vaccine_subject[t]);
        break;
        
        case 4:
        printf("%-17s",vaccine_subject[t]);
        break;

        default:
        printf("%-10s",vaccine_subject[t]);
      }
    }
    //i represents the index of chosen 
    //display chosen vaccine.
    printf("\n%-14s",VAC[i].name);
    printf("%-8s",VAC[i].code);
    printf("%-10s",VAC[i].country);
    printf("%-10d",VAC[i].dosage);
    printf("%-17.2f",VAC[i].pop_covered);
    printf("%-10d\n",VAC[i].quantity);

    printf("\nThe current vaccine quantity of %s(%s) is %d.", VAC[i].name, VAC[i].code, VAC[i].quantity);
    printf("\nAmount of vaccine received is %d.",rec_amount);
    printf("\nThe final quantity of vaccine is %d.",VAC[i].quantity += rec_amount);

    do
    {   
      //confirmation with user
      printf("\n\nIs the displayed information correct?");
      printf("\nY for yes and N for no...: ");
      confirmation = getchar();
      // remove 'enter' thats in the heap input.
      while (getchar() != 10)
      {
      }
    } while((confirmation != 'Y') && (confirmation != 'N'));

    if (confirmation == 'Y')
    {
      //reset
      line_count = 0;
      fvaccine = fopen("vaccine.txt","w");
      //write into file the vaccine subjects.
      for (t = 0; t < 6; t++)
      {
        fprintf(fvaccine,"%s,",vaccine_subject[t]);
      }
      fprintf(fvaccine,"\n");
      //write into file vaccine contents.
      for (k = 0; k < struc_count; k++)
      {
        for (j = 0; j < struc_count; j++)
        {
          if (VAC[j].quantity > num)
          {
            num = VAC[j].quantity;
            highest = j;
          } 
        }
        fprintf(fvaccine,"%s,",VAC[highest].name);
        fprintf(fvaccine,"%s,",VAC[highest].code);
        fprintf(fvaccine,"%s,",VAC[highest].country);
        fprintf(fvaccine,"%d,",VAC[highest].dosage);
        fprintf(fvaccine,"%.2f,",VAC[highest].pop_covered);
        fprintf(fvaccine,"%d,",VAC[highest].quantity);
        fprintf(fvaccine,"\n");
        VAC[highest].quantity = 0;
        num = 0;
        highest = 0;
      }
      printf("Processing....\nDONE!\n");
      fclose(fvaccine);

    }else{
      printf("Configuration will not be processed.\n");
      printf("Returning to main page...\n");
      return 0;
    }
  }
  return 1;
}