#include "main.h"
#include "function.h"

int main(void) {
  char command;
  
  while (command != 'x')
  {
    command = menu();
    switch(command)
    {
      case '1':
      display_vaccine();
      break;

      case '2':
      rec_or_dist();
      break;

      case '3':
      search();
      break;
      
      case '4':
      display_distributed();
      break;
      
      case 'x':
      printf("logging out...");
      break;
    }
    printf("Going back to main menu...\n\n");
  }
  return 0;
}