#include <stdio.h>
#include <string.h> // for strtok,strcpy,strcmp
#include <stdlib.h> // for atoi,atof