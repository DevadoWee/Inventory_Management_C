void display_vaccine();
int receive(char*code, int rec_amount);
char menu();
void rec_or_dist();
void search();
int distribute(char*code, int dist_amount, char*permission_id);
void display_distributed();