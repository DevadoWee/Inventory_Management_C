#include "main.h"
#define SIZE 10
#define BIG 100
//vaccine size is 5, 10 for reassurance.

struct vaccine
{
  char name[15];
  char code[6];
  char country[15];
  char dosage[8];
  char pop_covered[15];
  char quantity[10];
}VAC[SIZE];

struct dist
{
  char permission[6];
  char code[3];
  char initial_quantity[10];
  int dist_amount;
  char final_quantity[10];
}DIST[BIG];


int distribute(char*code, int dist_amount, char*permission_id)
{
  FILE *fdist;
  FILE *fvaccine;
  char confirmation;
  char *token;
  int struc_count = 0;
  int line_count = 0;
  int index = 0;
  int token_index = 0;
  char line[80];
  int c;
  char *vaccine_content[10];
  int i;
  int final_quantity;
  int k;
  int j;
  int num = 0;
  int highest = 1;
  int match = 0;
  int initial_quantity;
  char *dist_content[10];
  int struc_distribute = 0;


  printf("\nVaccine code is %s.\n",code);
  printf("The distributed amount is %d.\n",dist_amount);
  printf("The permission id is %s.\n",permission_id);

  do
    {   
      //confirmation with user
      printf("\nIs the displayed information correct?");
      printf("\nY for yes and N for no...: ");
      confirmation = getchar();
      // remove 'enter' thats in the heap input.
      while (getchar() != 10)
      {
      }
    } while((confirmation != 'Y') && (confirmation != 'N'));


  //validation of permission id and inputing content to structure.
  if (confirmation == 'Y')
  {
    fdist = fopen("dist.txt","r");
    while (( c = getc(fdist)) != EOF)
    {
      if ( c == 10)
      {
        if (line_count >= 1)
        {
          //token = subject but splitted by ,
          token = strtok(line,",");
          //reset index
          token_index = 0;

          while (token != NULL)
          {
            //change token to array
            dist_content[token_index++] = token;
            //when element = NUll, exit.
            token = strtok (NULL, ",");
          }
          
          //set each content to structure.
          strcpy(DIST[struc_distribute].permission,dist_content[0]);
          strcpy(DIST[struc_distribute].code,dist_content[1]);
          strcpy(DIST[struc_distribute].initial_quantity,dist_content[2]);
          DIST[struc_distribute].dist_amount = atoi(dist_content[3]);
          strcpy(DIST[struc_distribute].final_quantity,dist_content[4]);
          struc_distribute++;
        }
        line_count += 1;
        //reset line
        memset(line,0,79);
        //reset index for line
        index = 0;

      }else
      {
        line[index] = c;
        index++;
      }
    }
    fclose(fdist);
    //reset
    index = 0;
    line_count = 0;


    //permission_id duplication check
    for ( i = 0; i < struc_distribute; i++)
    {
      if (strcmp(DIST[i].permission,permission_id) == 0)
      {
        printf("\nPermission id: %s has already been registered.\n",DIST[i].permission);
        printf("Returning...\n\n");
        return 0;
      }
    }
  }

  

  //start of distribution process
  if (confirmation == 'Y')
  {
    //substract from vaccine.txt
    fvaccine = fopen("vaccine.txt","r");
    while (( c = getc(fvaccine)) != EOF)
    {
      if ( c == 10)
      {
        //token = subject but splitted by ,
        token = strtok(line,",");
        //reset index
        token_index = 0;

        while (token != NULL)
        {
          //change token to array
          vaccine_content[token_index++] = token;
          //when element = NUll, exit.
          token = strtok (NULL, ",");
        }
        
        //set each content to structure.
        strcpy(VAC[struc_count].name,vaccine_content[0]);
        strcpy(VAC[struc_count].code,vaccine_content[1]);
        strcpy(VAC[struc_count].country,vaccine_content[2]);
        strcpy(VAC[struc_count].dosage,vaccine_content[3]);
        strcpy(VAC[struc_count].pop_covered,vaccine_content[4]);
        strcpy(VAC[struc_count].quantity,vaccine_content[5]);
        struc_count++;

        line_count += 1;
        //reset line
        memset(line,0,79);
        //reset index for line
        index = 0;

      }else
      {
        line[index] = c;
        index++;
      }
    }
    fclose(fvaccine);
    
    //Find the code's quantity and then deduct.
    for (i = 1; i < struc_count; i++)
    {
      if (strcmp(VAC[i].code,code) == 0)
      {
        initial_quantity = atoi(VAC[i].quantity);
        final_quantity = initial_quantity - dist_amount;
        sprintf(VAC[i].quantity,"%d",final_quantity);
        match += 1;
        break;
      }
    }
    //return if no match
    if (match == 0)
    {
      printf("\nCode not found, try again...");
      return 0;
    }

    //re-write vaccine.txt with new quantity and sort.
    fvaccine = fopen("vaccine.txt","w");
    //subjects...
    fprintf(fvaccine,"%s,%s,%s,%s,%s,%s,\n",VAC[0].name,VAC[0].code,VAC[0].country,VAC[0].dosage,VAC[0].pop_covered,VAC[0].quantity);

    //content...in order
    for (k = 1; k < struc_count; k++)
    {
      for (j = 1; j < struc_count; j++)
      {
        if (atoi(VAC[j].quantity) > num)
        {
          num = atoi(VAC[j].quantity);
          highest = j;
        } 
      }
      fprintf(fvaccine,"%s,",VAC[highest].name);
      fprintf(fvaccine,"%s,",VAC[highest].code);
      fprintf(fvaccine,"%s,",VAC[highest].country);
      fprintf(fvaccine,"%s,",VAC[highest].dosage);
      fprintf(fvaccine,"%s,",VAC[highest].pop_covered);
      fprintf(fvaccine,"%s,",VAC[highest].quantity);
      fprintf(fvaccine,"\n");
      strcpy(VAC[highest].quantity,"0");
      num = 0;
      highest = 0;
    }
    fclose(fvaccine);


    //rewrite dist.txt for well, early sorting.
    strcpy(DIST[struc_distribute].permission,permission_id);
    strcpy(DIST[struc_distribute].code,code);
    sprintf(DIST[struc_distribute].initial_quantity,"%d",initial_quantity);
    DIST[struc_distribute].dist_amount = dist_amount;
    sprintf(DIST[struc_distribute].final_quantity,"%d",final_quantity);

    //re-write vaccine.txt with new quantity and sort.
    fdist = fopen("dist.txt","w");
    //subjects...
    fprintf(fdist,"ID,Code,Initial,Distributed,Final Quantity,\n");

    //content...in order
    for (k = 0; k < struc_distribute+1; k++)
    {
      for (j = 0; j < struc_distribute+1; j++)
      {
        if (DIST[j].dist_amount > num)
        {
          num = DIST[j].dist_amount;
          highest = j;
        } 
      }
      fprintf(fdist,"%s,",DIST[highest].permission);
      fprintf(fdist,"%s,",DIST[highest].code);
      fprintf(fdist,"%s,",DIST[highest].initial_quantity);
      fprintf(fdist,"%d,",DIST[highest].dist_amount);
      fprintf(fdist,"%s,",DIST[highest].final_quantity);
      fprintf(fdist,"\n");
      DIST[highest].dist_amount = 0;
      num = 0;
      highest = 0;
    }
    fclose(fdist);
    printf("Processing....\nDONE!\n");


  } else
  {
    printf("Please try again...\n");
    return 0;
  }
  return 1;
}
