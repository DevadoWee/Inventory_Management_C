#include "main.h"
#define BIG 100
#define SIZE 10
#define SUBJECT 5

struct dist
{
  char permission[6];
  char code[3];
  char initial_quantity[10];
  int dist_amount;
  char final_quantity[10];
}DIST[BIG];

struct total
{
  char code[3];
  int distributed_quantity;
}TOT[SIZE];

void display_distributed()
{
  char command;
  FILE *fdist;
  int c;
  int line_count = 0;
  char line[80];
  char *token;
  char *dist_content[10];
  int token_index;
  int struc_distribute = 0;
  int index = 0;
  int i;
  char code[3];
  int found = 0;
  int j;
  int total = 0;
  int k;
  int num = 0;
  int highest = 0;

  do {
    printf("\nType 1 to display all distributed vaccines' quantity.\n");
    printf("Type 2 to display chosen distributed vaccines' quantity.\n");
    printf("\nCommand: ");
    command = getchar();
    //get rid of the enter value
    while (getchar() != 10)
      {
      }
  } while ((command != '1') && (command != '2'));
  
  printf("\n");
  fdist = fopen("dist.txt","r");
  while (( c = getc(fdist)) != EOF)
  {
    if ( c == 10)
    {
      if (line_count >= 1)
      {
        //token = content but splitted by ,
        token = strtok(line,",");
        //reset index
        token_index = 0;

        while (token != NULL)
        {
          //change token to array
          dist_content[token_index++] = token;
          //when element = NUll, exit.
          token = strtok (NULL, ",");
        }
        
        //set each content to structure.
        strcpy(DIST[struc_distribute].permission,dist_content[0]);
        strcpy(DIST[struc_distribute].code,dist_content[1]);
        strcpy(DIST[struc_distribute].initial_quantity,dist_content[2]);
        DIST[struc_distribute].dist_amount = atoi(dist_content[3]);
        strcpy(DIST[struc_distribute].final_quantity,dist_content[4]);
        struc_distribute++;
      }
      line_count += 1;
      //reset line
      memset(line,0,79);
      //reset index for line
      index = 0;

    }else
    {
      line[index] = c;
      index++;
    }
  }
  fclose(fdist);


  if (command == '1')
  {
    for ( i = 0; i < SUBJECT; i++)
    {
      for ( j = 0; j < struc_distribute; j++)
      {
        if (strcmp(DIST[j].code,"0") != 0)
        {
          //copy to code <- for scope purposes
          strcpy(code,DIST[j].code);
          //copy to TOT structure for sorting.
          strcpy(TOT[i].code,DIST[j].code);
          break;
        }
      }

      for ( j = 0; j< struc_distribute; j++)
      {
        //add only based on code.
        if (strcmp(DIST[j].code,code) == 0)
        {
          total += DIST[j].dist_amount;
          strcpy(DIST[j].code,"0");
        }
      }
      TOT[i].distributed_quantity = total;
      total = 0;
    }

    printf("%-8s %-20s\n","Code","Total Distributed");

    //content...in order
    for (k = 0; k < SUBJECT; k++)
    {
      for (j = 0; j < SUBJECT; j++)
      {
        if (TOT[j].distributed_quantity > num)
        {
          num = TOT[j].distributed_quantity;
          highest = j;
        } 
      }
      printf("%-8s ",TOT[highest].code);
      printf("%-20d ",TOT[highest].distributed_quantity);
      printf("\n");

      TOT[highest].distributed_quantity = 0;
      num = 0;
      highest = 0;
    }


  }else if (command == '2')
  {
    printf("Please write down the vaccine code.\n");
    printf("Code: ");
    scanf("%s",code);
    //get rid of the enter value
    while (getchar() != 10)
      {
      }

    printf("%-6s %-7s %-14s %-14s %14s\n","ID","Code","Initial","Distributed","Final Quantity");

    //display content based on the code
    for ( i = 0; i < struc_distribute; i++)
    {
      if (strcmp(DIST[i].code,code) == 0)
      {
        printf("%-6s ",DIST[i].permission);
        printf("%-7s ",DIST[i].code);
        printf("%-14s ",DIST[i].initial_quantity);
        printf("%-14d ",DIST[i].dist_amount);
        printf("%-14s ",DIST[i].final_quantity);
        printf("\n");
        found += 1;
      }
    }
    //if code no match.
    if (found == 0)
    {
      printf("Wrong code, please try again...\n\n");
      display_distributed();
    }
  }
}