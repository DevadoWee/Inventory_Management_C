#include "main.h"
#include "function.h"

void rec_or_dist()
{
  char command;
  int success = 0;
  char code[3];
  int rec_amount;
  int dist_amount;
  char permission_id[6];
  char int_check;

  printf("\nPlease confirm if it's receiving or distributing.\n");
  printf("Type 1 to increase the quantity of vaccine.\n");
  printf("Type 2 to decrease the quantity of vaccine.\n");
  printf("\nCommand: ");
  command = getchar();
  //get rid of the enter value
  while (getchar() != 10)
      {
      }

  if (command == '1') 
  {
    while (success == 0)
    {
      printf("\nLoading...\nReceiving Vaccine!\n");
      printf("Please type down the vaccine code and the amount received.\n");
      printf("Type xx to exit.\n");
      printf("Vaccine code: ");
      scanf("%s",code);
      if (code[0] == 'x' && code[1] == 'x')
      {
        while (getchar() != 10)
          {
          }
        break;
      }
      while (getchar() != 10)
      {
      }
      printf("Amount received: ");
      scanf("%d",&rec_amount);
      //repeating until theres \n, works like gets()
      if (int_check)
      {
        continue;
      }
      while (getchar() != 10)
      {
      }
      success = receive(code,rec_amount);
    }


  } else if (command == '2')
  {
    while (success == 0)
    {
      printf("\nLoading...\nDistributing Vaccine!\n");
      printf("Please type down the vaccine code, the amount distributed \nand the permission id.\n");
      printf("Type xx to exit.\n");
      printf("Vaccine code: ");
      scanf("%s",code);
      if (code[0] == 'x' && code[1] == 'x')
      {
        while (getchar() != 10)
          {
          }
        break;
      }
      while (getchar() != 10)
      {
      }
      printf("Amount distributed: ");
      scanf("%d",&dist_amount);
      //repeating until theres \n, works like gets()
      while (getchar() != 10)
      {
      }

      printf("Permission id: ");
      scanf("%s",permission_id);
      while (getchar() != 10)
      {
      }

      success = distribute(code,dist_amount,permission_id);
    }
  } else{
    printf("Wrong command, returning to main manu...\n");
  }
}
